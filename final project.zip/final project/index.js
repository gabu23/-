document.addEventListener('DOMContentLoaded', function() {
    var menu = document.getElementById('menu');
    var burger = document.getElementById('burgermenulogin');

    burger.addEventListener('click', function() {
        if (menu.classList.contains('menu-hidden')) {
            menu.classList.remove('menu-hidden');
            menu.classList.add('menu-visible');
        } else {
            menu.classList.remove('menu-visible');
            menu.classList.add('menu-hidden');
        }
    });
});